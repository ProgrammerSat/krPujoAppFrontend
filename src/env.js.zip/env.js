const BASE_URL = 'http://3.72.104.209:3000';

export default BASE_URL;
